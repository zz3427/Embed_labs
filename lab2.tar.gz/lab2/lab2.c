/*
 *
 * CSEE 4840 Lab 2 for 2019 (adapted to Spring 2026 requirements)
 *
 * Name/UNI: zz3427 Gerald Zhao; dc3949 Derrick Chen; zw3161 Zening Wang
 */

#include "fbputchar.h"
#include "usbkeyboard.h"

#include <arpa/inet.h>
#include <linux/fb.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

//      arthur.cs.columbia.edu 
#define SERVER_HOST "128.59.19.114"
#define SERVER_PORT 42000

#define BUFFER_SIZE 256

#define INPUT_MAX 256
#define PROMPT "> "

//      Key repeat 
#define REPEAT_DELAY_MS 400
#define REPEAT_RATE_MS  45

//      ===== Forward declarations ===== 
static void compute_screen_layout(void);

static long long now_ms(void);

static void clear_line(int row);
static void clear_screen(void);
static void draw_separator(void);

static void rx_newline(void);
static void rx_putc(char ch);
static void rx_puts_wrapped(const char *s);

static void render_input(void);

static void input_clear(void);
static void input_insert_char(char ch);
static void input_backspace(void);
static void input_left(void);
static void input_right(void);

static int max_input_chars(void);

static int shift_down(uint8_t mods);
static char hid_to_ascii(uint8_t keycode, int shift);

static void send_current_input(void);
static void handle_keycode(uint8_t mods, uint8_t kc);

static int key_in_list(uint8_t kc, const uint8_t list[6]);
static void *network_thread_f(void *ignored);

//      ===== Globals ===== 
static int cols, rows;
static int rx_rows, sep_row, in_row0, in_row1;

static int sockfd = -1;
static struct libusb_device_handle *keyboard = NULL;
static uint8_t endpoint_address = 0;

static pthread_t network_thread;
static pthread_mutex_t fb_lock = PTHREAD_MUTEX_INITIALIZER;

static uint8_t prev_mods = 0;

//      Receive cursor 
static int rx_row = 0;
static int rx_col = 0;

//      Input state 
static char input_buf[INPUT_MAX];
static int input_len = 0;
static int input_cur = 0;

//      Repeat state 
static uint8_t held_keycode = 0;
static uint8_t held_mods = 0;
static int held_active = 0;
static long long held_next_ms = 0;

//      defined in fbputchar.c 
extern struct fb_var_screeninfo fb_vinfo;

static int rx_lines_needed_for(const char *s, int start_col) {
  int lines = 1;
  int col = start_col;

  for (const char *p = s; *p; p++) {
    char ch = *p;
    if (ch == '\r') continue;

    if (ch == '\n') {
      lines++;
      col = 0;
      continue;
    }

    col++;
    if (col >= cols) {
      lines++;
      col = 0;
    }
  }
  return lines;
}

static void compute_screen_layout(void) {
  cols = (int)(fb_vinfo.xres / 16);
  rows = (int)(fb_vinfo.yres / 32);

  if (cols < 10) cols = 10;
  if (rows < 6)  rows = 6;

  rx_rows = rows - 3;
  sep_row = rows - 3;
  in_row0 = rows - 2;
  in_row1 = rows - 1;
}

static long long now_ms(void) {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return (long long)tv.tv_sec * 1000LL + tv.tv_usec / 1000LL;
}

//      ===== Framebuffer helpers ===== 
static void clear_line(int row) {
  for (int c = 0; c < cols; c++) fbputchar(' ', row, c);
}

static void clear_screen(void) {
  for (int r = 0; r < rows; r++) clear_line(r);
}

static void draw_separator(void) {
  for (int c = 0; c < cols; c++) fbputchar('-', sep_row, c);
}

//      ===== Receive region printing ===== 
static void rx_newline(void) {
  rx_row++;
  rx_col = 0;

  if (rx_row >= rx_rows) {
    //      Requirement: once screen is full, clear whole screen 
    clear_screen();
    draw_separator();
    rx_row = 0;
    rx_col = 0;
    render_input();
  }
  clear_line(rx_row);
}

static void rx_putc(char ch) {
  if (ch == '\r') return;

  if (ch == '\n') {
    rx_newline();
    return;
  }

  if (rx_col >= cols) rx_newline();

  fbputchar(ch, rx_row, rx_col);
  rx_col++;

  if (rx_col >= cols) rx_newline();
}

static void rx_puts_wrapped(const char *s) {
  for (const char *p = s; *p; p++) rx_putc(*p);
}

//      ===== Input rendering / editing ===== 
static int max_input_chars(void) {
  int prompt_len = (int)strlen(PROMPT);
  int cap = 2 * cols - prompt_len - 1; //      keep room for cursor 
  if (cap < 0) cap = 0;
  if (cap > INPUT_MAX - 1) cap = INPUT_MAX - 1;
  return cap;
}

static void render_input(void) {
  clear_line(in_row0);
  clear_line(in_row1);

  char disp[INPUT_MAX + 8];
  snprintf(disp, sizeof(disp), "%s%.*s", PROMPT, input_len, input_buf);

  int total = (int)strlen(disp);
  int max_chars = 2 * cols;
  if (total > max_chars) {
    //      should not happen due to cap, but safe 
    total = max_chars;
    disp[total] = '\0';
  }

  for (int i = 0; i < total; i++) {
    int r = (i < cols) ? in_row0 : in_row1;
    int c = (i < cols) ? i : (i - cols);
    fbputchar(disp[i], r, c);
  }

  int cursor_pos = (int)strlen(PROMPT) + input_cur;
  if (cursor_pos < 0) cursor_pos = 0;
  if (cursor_pos >= 2 * cols) cursor_pos = 2 * cols - 1;

  int cr = (cursor_pos < cols) ? in_row0 : in_row1;
  int cc = (cursor_pos < cols) ? cursor_pos : (cursor_pos - cols);
  fbputchar('_', cr, cc);
}

static void input_clear(void) {
  memset(input_buf, 0, sizeof(input_buf));
  input_len = 0;
  input_cur = 0;
}

static void input_insert_char(char ch) {
  int cap = max_input_chars();
  if (input_len >= cap) return;
  if (input_len >= INPUT_MAX - 1) return;

  if (input_cur < 0) input_cur = 0;
  if (input_cur > input_len) input_cur = input_len;

  memmove(&input_buf[input_cur + 1], &input_buf[input_cur],
          (size_t)(input_len - input_cur));
  input_buf[input_cur] = ch;
  input_len++;
  input_cur++;
}

static void input_backspace(void) {
  if (input_cur <= 0 || input_len <= 0) return;

  memmove(&input_buf[input_cur - 1], &input_buf[input_cur],
          (size_t)(input_len - input_cur));
  input_len--;
  input_cur--;
}

static void input_left(void) {
  if (input_cur > 0) input_cur--;
}

static void input_right(void) {
  if (input_cur < input_len) input_cur++;
}

//      ===== HID mapping ===== 
static int shift_down(uint8_t mods) {
  return (mods & 0x02) || (mods & 0x20);
}

static char hid_to_ascii(uint8_t keycode, int shift) {
  if (keycode >= 0x04 && keycode <= 0x1d) {
    char base = (char)('a' + (keycode - 0x04));
    return shift ? (char)(base - 32) : base;
  }

  if (keycode >= 0x1e && keycode <= 0x27) {
    static const char normal[]  = "1234567890";
    static const char shifted[] = "!@#$%^&*()";
    int idx = keycode - 0x1e;
    return shift ? shifted[idx] : normal[idx];
  }

  switch (keycode) {
    case 0x2c: return ' ';
    case 0x2d: return shift ? '_' : '-';
    case 0x2e: return shift ? '+' : '=';
    case 0x2f: return shift ? '{' : '[';
    case 0x30: return shift ? '}' : ']';
    case 0x31: return shift ? '|' : '\\';
    case 0x33: return shift ? ':' : ';';
    case 0x34: return shift ? '"' : '\'';
    case 0x35: return shift ? '~' : '`';
    case 0x36: return shift ? '<' : ',';
    case 0x37: return shift ? '>' : '.';
    case 0x38: return shift ? '?' : '/';
    default:   return 0;
  }
}

//      ===== Sending / key handling ===== 
static void send_current_input(void) {
  char out[INPUT_MAX + 4];
  int n = snprintf(out, sizeof(out), "%.*s\n", input_len, input_buf);
  if (n <= 0) return;

  (void)write(sockfd, out, (size_t)n);

  //      No local echo to avoid duplicates (<ip> ... will come from server) 
  pthread_mutex_lock(&fb_lock);
  input_clear();
  render_input();
  pthread_mutex_unlock(&fb_lock);
}

static void handle_keycode(uint8_t mods, uint8_t kc) {
  if (kc == 0) return;

  //      ESC 
  if (kc == 0x29) {
    pthread_cancel(network_thread);
    if (sockfd >= 0) close(sockfd);
    exit(0);
  }

  //      Enter 
  if (kc == 0x28) {
    if (input_len > 0) {
      send_current_input();
    } else {
      pthread_mutex_lock(&fb_lock);
      input_clear();
      render_input();
      pthread_mutex_unlock(&fb_lock);
    }
    return;
  }

  //      Backspace 
  if (kc == 0x2a) {
    pthread_mutex_lock(&fb_lock);
    input_backspace();
    render_input();
    pthread_mutex_unlock(&fb_lock);
    return;
  }

  //      Left / Right 
  if (kc == 0x50) {
    pthread_mutex_lock(&fb_lock);
    input_left();
    render_input();
    pthread_mutex_unlock(&fb_lock);
    return;
  }
  if (kc == 0x4f) {
    pthread_mutex_lock(&fb_lock);
    input_right();
    render_input();
    pthread_mutex_unlock(&fb_lock);
    return;
  }

  //      Printable 
  char ch = hid_to_ascii(kc, shift_down(mods));
  if (ch) {
    pthread_mutex_lock(&fb_lock);
    input_insert_char(ch);
    render_input();
    pthread_mutex_unlock(&fb_lock);
  }
}

//      ===== Key helpers ===== 
static int key_in_list(uint8_t kc, const uint8_t list[6]) {
  for (int i = 0; i < 6; i++) if (list[i] == kc) return 1;
  return 0;
}

//      ===== Network thread ===== 
static void *network_thread_f(void *ignored) {
  char recvBuf[BUFFER_SIZE];
  int n;

  while ((n = (int)read(sockfd, recvBuf, BUFFER_SIZE - 1)) > 0) {
    recvBuf[n] = '\0';

    pthread_mutex_lock(&fb_lock);

  //      Pre-clear if this incoming chunk won't fit in remaining receive rows 
  int remaining = rx_rows - rx_row;                 // rows left including current row
  int need = rx_lines_needed_for(recvBuf, rx_col);  // how many lines this chunk will take

  if (need > remaining) {
    clear_screen();
    draw_separator();
    rx_row = 0;
    rx_col = 0;
    render_input();          // keep input visible
    clear_line(rx_row);      // optional: ensure first rx row is blank
  }

  rx_puts_wrapped(recvBuf);
  render_input();
  pthread_mutex_unlock(&fb_lock);

    write(STDOUT_FILENO, recvBuf, (size_t)n);
  }
  return NULL;
}

//      ===== main ===== 
int main(void) {
  int err;
  struct sockaddr_in serv_addr;

  struct usb_keyboard_packet packet;
  int transferred;

  uint8_t prev_keys[6] = {0};

  if ((err = fbopen()) != 0) {
    fprintf(stderr, "Error: Could not open framebuffer: %d\n", err);
    exit(1);
  }
  compute_screen_layout();

  pthread_mutex_lock(&fb_lock);
  clear_screen();
  draw_separator();
  rx_row = 0;
  rx_col = 0;
  input_clear();
  render_input();
  pthread_mutex_unlock(&fb_lock);

  if ((keyboard = openkeyboard(&endpoint_address)) == NULL) {
    fprintf(stderr, "Did not find a keyboard\n");
    exit(1);
  }

  if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    fprintf(stderr, "Error: Could not create socket\n");
    exit(1);
  }

  memset(&serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port = htons(SERVER_PORT);

  if (inet_pton(AF_INET, SERVER_HOST, &serv_addr.sin_addr) <= 0) {
    fprintf(stderr, "Error: Could not convert host IP \"%s\"\n", SERVER_HOST);
    exit(1);
  }

  if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
    fprintf(stderr, "Error: connect() failed. Is the server reachable?\n");
    exit(1);
  }

  pthread_create(&network_thread, NULL, network_thread_f, NULL);

  for (;;) {
    libusb_interrupt_transfer(keyboard, endpoint_address,
                              (unsigned char *)&packet, sizeof(packet),
                              &transferred, 0);
    if (transferred != (int)sizeof(packet)) continue;

    uint8_t mods = packet.modifiers;
    int mods_changed = (mods != prev_mods);

    int all_zero = 1;
    for (int i = 0; i < 6; i++) {
      if (packet.keycode[i] != 0) { all_zero = 0; break; }
    }
    if (mods_changed && all_zero) {
      prev_mods = mods;
      //      Do NOT overwrite prev_keys. Skip processing this packet. 
      continue;
    }

    //      Deduplicate keys within this packet 
    uint8_t seen[6] = {0};

    int any_new_press = 0;

    //      Handle newly pressed keys 
    for (int i = 0; i < 6; i++) {
      uint8_t kc = packet.keycode[i];
      if (kc == 0) continue;

      if (key_in_list(kc, seen)) continue;
      seen[i] = kc;

      if (!key_in_list(kc, prev_keys)) {
        any_new_press = 1;
        handle_keycode(mods, kc);

        //      Arm repeat for this key (only once per new press) 
        held_keycode = kc;
        held_mods = mods;
        held_active = 1;
        held_next_ms = now_ms() + REPEAT_DELAY_MS;
      }
    }

    prev_mods = mods;

    //      Repeat: only if held key still down, no modifier glitch, and not same-cycle new press 
    if (held_active) {
      int still_down = 0;
      for (int i = 0; i < 6; i++) {
        if (packet.keycode[i] == held_keycode) { still_down = 1; break; }
      }

      if (!still_down) {
        held_active = 0;
      } else if (!mods_changed && !any_new_press) {
        long long t = now_ms();
        if (t >= held_next_ms) {
          if (held_keycode == 0x2a || held_keycode == 0x4f || held_keycode == 0x50 ||
              hid_to_ascii(held_keycode, shift_down(held_mods))) {
            handle_keycode(held_mods, held_keycode);
          }
          held_next_ms = t + REPEAT_RATE_MS;
        }
      }
    }

    //      Save previous keycodes 
    memcpy(prev_keys, packet.keycode, 6);
  }

  return 0;
}